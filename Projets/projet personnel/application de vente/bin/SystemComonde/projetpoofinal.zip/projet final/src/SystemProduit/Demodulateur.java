package SystemProduit;

import java.util.ArrayList;

public class Demodulateur extends Electrionique {

    public Demodulateur(String nom, String referonce, String descriptif, ArrayList<String> ensembleCaracteristiques,
            ArrayList<String> ensembleInformationDeRecherche, double prix) {
        super(nom, referonce, descriptif, ensembleCaracteristiques, ensembleInformationDeRecherche, prix);
        //TODO Auto-generated constructor stub
    }

    
    
}
