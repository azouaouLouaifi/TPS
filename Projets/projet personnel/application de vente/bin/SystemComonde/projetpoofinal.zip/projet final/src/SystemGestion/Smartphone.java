package SystemGestion;

public class Smartphone extends Client {
    
}