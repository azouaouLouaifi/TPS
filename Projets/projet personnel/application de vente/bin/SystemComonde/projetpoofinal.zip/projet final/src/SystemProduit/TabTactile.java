package SystemProduit;

import java.util.ArrayList;

public class TabTactile extends Mobile{

    public TabTactile(String nom, String referonce, ArrayList<String> ensembleCaracteristiques,ArrayList<String> ensembleInformationDeRecherche, double prix) {
        super(nom, referonce, ensembleCaracteristiques, ensembleInformationDeRecherche, prix);
        //TODO Auto-generated constructor stub
    }}