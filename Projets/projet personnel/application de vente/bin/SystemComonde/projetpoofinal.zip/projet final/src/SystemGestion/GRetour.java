package SystemGestion;

public interface GRetour {
    public void retourCommande() ;
}
