package SystemProduit;

import java.util.ArrayList;

public class ObjetConnecte extends Mobile {

    public ObjetConnecte(String nom, String referonce,  ArrayList<String> ensembleCaracteristiques,ArrayList<String> ensembleInformationDeRecherche, double prix) {
        super(nom, referonce, ensembleCaracteristiques, ensembleInformationDeRecherche, prix);
        //TODO Auto-generated constructor stub
    }
    
}