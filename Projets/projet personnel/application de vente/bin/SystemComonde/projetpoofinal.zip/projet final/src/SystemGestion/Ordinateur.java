package SystemGestion;

public class Ordinateur extends Client {
    
}
