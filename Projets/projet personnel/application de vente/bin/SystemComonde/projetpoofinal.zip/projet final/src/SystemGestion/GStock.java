package SystemGestion;

public interface GStock {
    public void ajoutProduit();

}
